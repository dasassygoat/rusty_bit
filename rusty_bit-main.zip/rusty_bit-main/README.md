# rusty_bit


[![pipeline status](https://gitlab.com/lpr10/rusty_bit/badges/main/pipeline.svg)](https://gitlab.com/lpr10/rusty_bit/-/commits/main) 

https://www.youtube.com/watch?v=md-ecvXBGzI
